/**
  ******************************************************************************
  * @file    oled.c
  * @brief   SSD1306 OLED driver (Software I2C: PA6=SCL, PA7=SDA)
  *          Resolution: 128x64, I2C address: 0x3C
  ******************************************************************************
  */

#include "oled.h"

/* =========================== 6x8 ASCII Font =============================== */
/* Standard 6x8 font, 96 printable characters (0x20 ~ 0x7F) */
static const uint8_t Font6x8[][6] = {
    {0x00,0x00,0x00,0x00,0x00,0x00}, /*   (space) */
    {0x00,0x00,0x5F,0x00,0x00,0x00}, /* ! */
    {0x00,0x07,0x00,0x07,0x00,0x00}, /* " */
    {0x14,0x7F,0x14,0x7F,0x14,0x00}, /* # */
    {0x24,0x2A,0x7F,0x2A,0x12,0x00}, /* $ */
    {0x23,0x13,0x08,0x64,0x62,0x00}, /* % */
    {0x36,0x49,0x55,0x22,0x50,0x00}, /* & */
    {0x00,0x05,0x03,0x00,0x00,0x00}, /* ' */
    {0x00,0x1C,0x22,0x41,0x00,0x00}, /* ( */
    {0x00,0x41,0x22,0x1C,0x00,0x00}, /* ) */
    {0x08,0x2A,0x1C,0x2A,0x08,0x00}, /* * */
    {0x08,0x08,0x3E,0x08,0x08,0x00}, /* + */
    {0x00,0x50,0x30,0x00,0x00,0x00}, /* , */
    {0x08,0x08,0x08,0x08,0x08,0x00}, /* - */
    {0x00,0x60,0x60,0x00,0x00,0x00}, /* . */
    {0x20,0x10,0x08,0x04,0x02,0x00}, /* / */
    {0x3E,0x51,0x49,0x45,0x3E,0x00}, /* 0 */
    {0x00,0x42,0x7F,0x40,0x00,0x00}, /* 1 */
    {0x42,0x61,0x51,0x49,0x46,0x00}, /* 2 */
    {0x21,0x41,0x45,0x4B,0x31,0x00}, /* 3 */
    {0x18,0x14,0x12,0x7F,0x10,0x00}, /* 4 */
    {0x27,0x45,0x45,0x45,0x39,0x00}, /* 5 */
    {0x3C,0x4A,0x49,0x49,0x30,0x00}, /* 6 */
    {0x01,0x71,0x09,0x05,0x03,0x00}, /* 7 */
    {0x36,0x49,0x49,0x49,0x36,0x00}, /* 8 */
    {0x06,0x49,0x49,0x29,0x1E,0x00}, /* 9 */
    {0x00,0x36,0x36,0x00,0x00,0x00}, /* : */
    {0x00,0x56,0x36,0x00,0x00,0x00}, /* ; */
    {0x00,0x08,0x14,0x22,0x41,0x00}, /* < */
    {0x14,0x14,0x14,0x14,0x14,0x00}, /* = */
    {0x41,0x22,0x14,0x08,0x00,0x00}, /* > */
    {0x02,0x01,0x51,0x09,0x06,0x00}, /* ? */
    {0x32,0x49,0x79,0x41,0x3E,0x00}, /* @ */
    {0x7E,0x11,0x11,0x11,0x7E,0x00}, /* A */
    {0x7F,0x49,0x49,0x49,0x36,0x00}, /* B */
    {0x3E,0x41,0x41,0x41,0x22,0x00}, /* C */
    {0x7F,0x41,0x41,0x22,0x1C,0x00}, /* D */
    {0x7F,0x49,0x49,0x49,0x41,0x00}, /* E */
    {0x7F,0x09,0x09,0x01,0x01,0x00}, /* F */
    {0x3E,0x41,0x41,0x51,0x32,0x00}, /* G */
    {0x7F,0x08,0x08,0x08,0x7F,0x00}, /* H */
    {0x00,0x41,0x7F,0x41,0x00,0x00}, /* I */
    {0x20,0x40,0x41,0x3F,0x01,0x00}, /* J */
    {0x7F,0x08,0x14,0x22,0x41,0x00}, /* K */
    {0x7F,0x40,0x40,0x40,0x40,0x00}, /* L */
    {0x7F,0x02,0x04,0x02,0x7F,0x00}, /* M */
    {0x7F,0x04,0x08,0x10,0x7F,0x00}, /* N */
    {0x3E,0x41,0x41,0x41,0x3E,0x00}, /* O */
    {0x7F,0x09,0x09,0x09,0x06,0x00}, /* P */
    {0x3E,0x41,0x51,0x21,0x5E,0x00}, /* Q */
    {0x7F,0x09,0x19,0x29,0x46,0x00}, /* R */
    {0x46,0x49,0x49,0x49,0x31,0x00}, /* S */
    {0x01,0x01,0x7F,0x01,0x01,0x00}, /* T */
    {0x3F,0x40,0x40,0x40,0x3F,0x00}, /* U */
    {0x1F,0x20,0x40,0x20,0x1F,0x00}, /* V */
    {0x7F,0x20,0x18,0x20,0x7F,0x00}, /* W */
    {0x63,0x14,0x08,0x14,0x63,0x00}, /* X */
    {0x03,0x04,0x78,0x04,0x03,0x00}, /* Y */
    {0x61,0x51,0x49,0x45,0x43,0x00}, /* Z */
    {0x00,0x00,0x7F,0x41,0x41,0x00}, /* [ */
    {0x02,0x04,0x08,0x10,0x20,0x00}, /* \ */
    {0x41,0x41,0x7F,0x00,0x00,0x00}, /* ] */
    {0x04,0x02,0x01,0x02,0x04,0x00}, /* ^ */
    {0x40,0x40,0x40,0x40,0x40,0x00}, /* _ */
    {0x00,0x01,0x02,0x04,0x00,0x00}, /* ` */
    {0x20,0x54,0x54,0x54,0x78,0x00}, /* a */
    {0x7F,0x48,0x44,0x44,0x38,0x00}, /* b */
    {0x38,0x44,0x44,0x44,0x20,0x00}, /* c */
    {0x38,0x44,0x44,0x48,0x7F,0x00}, /* d */
    {0x38,0x54,0x54,0x54,0x18,0x00}, /* e */
    {0x08,0x7E,0x09,0x01,0x02,0x00}, /* f */
    {0x08,0x14,0x54,0x54,0x3C,0x00}, /* g */
    {0x7F,0x08,0x04,0x04,0x78,0x00}, /* h */
    {0x00,0x44,0x7D,0x40,0x00,0x00}, /* i */
    {0x20,0x40,0x44,0x3D,0x00,0x00}, /* j */
    {0x00,0x7F,0x10,0x28,0x44,0x00}, /* k */
    {0x00,0x41,0x7F,0x40,0x00,0x00}, /* l */
    {0x7C,0x04,0x18,0x04,0x78,0x00}, /* m */
    {0x7C,0x08,0x04,0x04,0x78,0x00}, /* n */
    {0x38,0x44,0x44,0x44,0x38,0x00}, /* o */
    {0x7C,0x14,0x14,0x14,0x08,0x00}, /* p */
    {0x08,0x14,0x14,0x18,0x7C,0x00}, /* q */
    {0x7C,0x08,0x04,0x04,0x08,0x00}, /* r */
    {0x48,0x54,0x54,0x54,0x20,0x00}, /* s */
    {0x04,0x3F,0x44,0x40,0x20,0x00}, /* t */
    {0x3C,0x40,0x40,0x20,0x7C,0x00}, /* u */
    {0x1C,0x20,0x40,0x20,0x1C,0x00}, /* v */
    {0x3C,0x40,0x30,0x40,0x3C,0x00}, /* w */
    {0x44,0x28,0x10,0x28,0x44,0x00}, /* x */
    {0x0C,0x50,0x50,0x50,0x3C,0x00}, /* y */
    {0x44,0x64,0x54,0x4C,0x44,0x00}, /* z */
    {0x00,0x08,0x36,0x41,0x00,0x00}, /* { */
    {0x00,0x00,0x7F,0x00,0x00,0x00}, /* | */
    {0x00,0x41,0x36,0x08,0x00,0x00}, /* } */
    {0x08,0x04,0x08,0x10,0x08,0x00}, /* ~ */
};

/* =========================== Display Buffer =============================== */
uint8_t OLED_Buffer[OLED_PAGES][OLED_WIDTH];

/* ====================== Software I2C Low-Level ============================ */

/**
  * @brief  Set SDA as open-drain output (driven by STM32)
  */
static void OLED_SDA_Out(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Pin   = OLED_SDA_PIN;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_OD;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(OLED_PORT, &GPIO_InitStructure);
}

/**
  * @brief  Set SDA as input (float, external pull-up holds high; slave can pull low for ACK)
  */
static void OLED_SDA_In(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Pin   = OLED_SDA_PIN;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(OLED_PORT, &GPIO_InitStructure);
}

#define SCL_H()  GPIO_SetBits(OLED_PORT, OLED_SCL_PIN)
#define SCL_L()  GPIO_ResetBits(OLED_PORT, OLED_SCL_PIN)
#define SDA_H()  GPIO_SetBits(OLED_PORT, OLED_SDA_PIN)
#define SDA_L()  GPIO_ResetBits(OLED_PORT, OLED_SDA_PIN)

#define SDA_READ()  GPIO_ReadInputDataBit(OLED_PORT, OLED_SDA_PIN)

/**
  * @brief  Microsecond delay (tuned for 72MHz Cortex-M3, ~1µs per unit)
  */
static void OLED_DelayUs(uint32_t us)
{
    uint32_t i;
    for (i = 0; i < us * 18; i++)
    {
        __NOP();
    }
}

/**
  * @brief  Generate I2C start condition
  */
static void OLED_I2C_Start(void)
{
    OLED_SDA_Out();
    SDA_H();
    SCL_H();
    OLED_DelayUs(5);
    SDA_L();
    OLED_DelayUs(5);
    SCL_L();
}

/**
  * @brief  Generate I2C stop condition
  */
static void OLED_I2C_Stop(void)
{
    OLED_SDA_Out();
    SDA_L();
    OLED_DelayUs(2);
    SCL_H();
    OLED_DelayUs(5);
    SDA_H();
    OLED_DelayUs(5);
}

/**
  * @brief  Send one byte via I2C, return ACK (0 = ACK, 1 = NACK)
  */
static uint8_t OLED_I2C_SendByte(uint8_t byte)
{
    uint8_t i, ack;

    OLED_SDA_Out();

    for (i = 0; i < 8; i++)
    {
        if (byte & 0x80)
            SDA_H();
        else
            SDA_L();
        byte <<= 1;
        OLED_DelayUs(2);
        SCL_H();
        OLED_DelayUs(5);
        SCL_L();
        OLED_DelayUs(2);
    }

    /* Read ACK: switch SDA to input so slave can pull it low */
    OLED_SDA_In();
    SCL_H();
    OLED_DelayUs(5);
    ack = SDA_READ();
    SCL_L();
    OLED_DelayUs(2);

    return ack;  /* 0 = ACK, 1 = NACK */
}

/**
  * @brief  Send command byte to SSD1306
  */
static void OLED_WriteCmd(uint8_t cmd)
{
    OLED_I2C_Start();
    OLED_I2C_SendByte(OLED_ADDR);      /* Slave address + Write */
    OLED_I2C_SendByte(0x00);           /* Control byte: command */
    OLED_I2C_SendByte(cmd);            /* Command byte */
    OLED_I2C_Stop();
}

/**
  * @brief  Send data byte to SSD1306
  */
static void OLED_WriteData(uint8_t dat)
{
    OLED_I2C_Start();
    OLED_I2C_SendByte(OLED_ADDR);      /* Slave address + Write */
    OLED_I2C_SendByte(0x40);           /* Control byte: data */
    OLED_I2C_SendByte(dat);            /* Data byte */
    OLED_I2C_Stop();
}

/**
  * @brief  Set cursor position (page, column)
  */
static void OLED_SetPos(uint8_t page, uint8_t col)
{
    OLED_WriteCmd(0xB0 + page);                    /* Set page address (0~7) */
    OLED_WriteCmd(0x00 + (col & 0x0F));            /* Set lower column address */
    OLED_WriteCmd(0x10 + ((col >> 4) & 0x0F));     /* Set higher column address */
}

/* ======================== Public API ====================================== */

/**
  * @brief  Initialize SSD1306 OLED display
  */
void OLED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    /* Enable GPIOA clock */
    RCC_APB2PeriphClockCmd(OLED_RCC, ENABLE);

    /* Configure PA6 (SCL) as open-drain output */
    GPIO_InitStructure.GPIO_Pin   = OLED_SCL_PIN;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_OD;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(OLED_PORT, &GPIO_InitStructure);

    /* Configure PA7 (SDA) as open-drain output initially */
    OLED_SDA_Out();

    /* Set both pins high (float, pulled up externally) */
    SCL_H();
    SDA_H();

    /* Wait >100ms for SSD1306 power-up */
    OLED_DelayUs(100000);

    /* SSD1306 initialization sequence */
    OLED_WriteCmd(0xAE);  /* Display OFF */

    OLED_WriteCmd(0xD5);  /* Set display clock divide ratio/oscillator frequency */
    OLED_WriteCmd(0x80);

    OLED_WriteCmd(0xA8);  /* Set multiplex ratio */
    OLED_WriteCmd(0x3F);  /* 64 lines */

    OLED_WriteCmd(0xD3);  /* Set display offset */
    OLED_WriteCmd(0x00);

    OLED_WriteCmd(0x40);  /* Set start line */

    OLED_WriteCmd(0x8D);  /* Set charge pump */
    OLED_WriteCmd(0x14);  /* Enable charge pump (0x14 = enable, 0x10 = disable) */

    OLED_WriteCmd(0xA1);  /* Set segment re-map (column 127 mapped to SEG0) */
    OLED_WriteCmd(0xC8);  /* Set COM output scan direction (remapped) */

    OLED_WriteCmd(0xDA);  /* Set COM pins hardware configuration */
    OLED_WriteCmd(0x12);

    OLED_WriteCmd(0x81);  /* Set contrast */
    OLED_WriteCmd(0xCF);

    OLED_WriteCmd(0xD9);  /* Set pre-charge period */
    OLED_WriteCmd(0xF1);

    OLED_WriteCmd(0xDB);  /* Set VCOMH deselect level */
    OLED_WriteCmd(0x40);

    OLED_WriteCmd(0xA4);  /* Entire display ON (follows RAM content) */
    OLED_WriteCmd(0xA6);  /* Set normal display (0xA7 = inverse) */

    OLED_WriteCmd(0x20);  /* Set memory addressing mode */
    OLED_WriteCmd(0x00);  /* Horizontal addressing mode */

    OLED_WriteCmd(0xAF);  /* Display ON */

    /* Clear buffer and display */
    OLED_Clear();
    OLED_Refresh();
}

/**
  * @brief  Clear display buffer
  */
void OLED_Clear(void)
{
    uint8_t page, col;
    for (page = 0; page < OLED_PAGES; page++)
    {
        for (col = 0; col < OLED_WIDTH; col++)
        {
            OLED_Buffer[page][col] = 0x00;
        }
    }
}

/**
  * @brief  Flush entire buffer to OLED
  */
void OLED_Refresh(void)
{
    uint8_t page, col;
    for (page = 0; page < OLED_PAGES; page++)
    {
        OLED_SetPos(page, 0);
        for (col = 0; col < OLED_WIDTH; col++)
        {
            OLED_WriteData(OLED_Buffer[page][col]);
        }
    }
}

/**
  * @brief  Draw a single pixel at (x, y)
  */
void OLED_DrawPixel(uint8_t x, uint8_t y, uint8_t color)
{
    if (x >= OLED_WIDTH || y >= OLED_HEIGHT)
        return;

    if (color)
        OLED_Buffer[y / 8][x] |=  (1 << (y % 8));
    else
        OLED_Buffer[y / 8][x] &= ~(1 << (y % 8));
}

/**
  * @brief  Show a 6x8 character at page position
  */
void OLED_ShowChar(uint8_t x, uint8_t y, char ch)
{
    uint8_t i;
    uint8_t index;

    if (x > OLED_WIDTH - 6 || y > OLED_PAGES - 1)
        return;

    index = (uint8_t)ch - 0x20;  /* Printable ASCII starts at 0x20 (space) */
    if (index > 94) index = 0;   /* Out of range -> space */

    for (i = 0; i < 6; i++)
    {
        OLED_Buffer[y][x + i] = Font6x8[index][i];
    }
}

/**
  * @brief  Show a string at page position
  */
void OLED_ShowString(uint8_t x, uint8_t y, const char *str)
{
    while (*str)
    {
        OLED_ShowChar(x, y, *str);
        x += 6;
        if (x > OLED_WIDTH - 6)
        {
            x = 0;
            y++;
            if (y >= OLED_PAGES)
                return;
        }
        str++;
    }
}

/**
  * @brief  Print string with automatic newline (convenience)
  */
void OLED_Print(uint8_t x, uint8_t y, const char *str)
{
    OLED_ShowString(x, y, str);
    OLED_Refresh();
}

/* ====================== 16x16 Chinese Characters =========================== */

/**
  * @brief  16x16 Chinese character bitmaps (32 bytes each)
  *         Format: 16 rows, each row = [left_8_pixels, right_8_pixels]
  *         MSB = leftmost pixel within each byte.
  *
  *         To generate pixel-perfect bitmaps, use a font generation tool:
  *           - PCtoLCD2002  (Windows, most popular)
  *           - zimo221      (Windows)
  *           - lcd-image-converter (cross-platform)
  *         Settings: 16x16, column-major, MSB-first, C51 format.
  *
  *         Below bitmaps are HZK16 standard reference (GB2312 Song 16x16).
  */

/* 柒 — SimSun 宋体 16x16 点阵 (PIL 64px → 16px LANCZOS) */
const uint8_t CN_QI[32] = {
    0x08,0x40, 0x08,0x40, 0x20,0x44, 0x10,0x40,
    0x00,0xC0, 0x18,0x40, 0x18,0x40, 0x10,0x7C,
    0x10,0x80, 0x01,0x86, 0x03,0x80, 0x02,0x80,
    0x04,0xB0, 0x18,0x8C, 0x20,0x84, 0x00,0x00
};

/* 染 — SimSun 宋体 16x16 点阵 (PIL 64px → 16px LANCZOS) */
const uint8_t CN_RAN[32] = {
    0x10,0x80, 0x08,0x80, 0x00,0x90, 0x20,0x90,
    0x00,0x90, 0x01,0x10, 0x11,0x12, 0x12,0x1E,
    0x10,0x80, 0x00,0x84, 0x03,0x84, 0x03,0x80,
    0x04,0xA0, 0x08,0x98, 0x10,0x8C, 0x00,0x00
};

/**
  * @brief  Show a 16x16 Chinese character at pixel position
  * @param  x:      left column (0 ~ 112)
  * @param  y:      top row in PAGES (0 ~ 6), each page = 8 pixels
  *                 the character occupies y and y+1 (16 pixels = 2 pages)
  * @param  bitmap: 32-byte array [row0_L, row0_R, ... row15_L, row15_R]
  */
void OLED_ShowCN16(uint8_t x, uint8_t y, const uint8_t *bitmap)
{
    uint8_t row, col;
    uint8_t page, bit;

    for (row = 0; row < 16; row++)
    {
        page = y + row / 8;     /* first 8 rows → page y, next 8 → page y+1 */
        bit  = row % 8;         /* bit position within that page */

        if (page >= OLED_PAGES)
            continue;

        /* Left 8 pixels (columns x+0 ~ x+7) */
        for (col = 0; col < 8; col++)
        {
            if (x + col < OLED_WIDTH && (bitmap[row * 2] & (0x80 >> col)))
                OLED_Buffer[page][x + col] |= (1 << bit);
        }

        /* Right 8 pixels (columns x+8 ~ x+15) */
        for (col = 0; col < 8; col++)
        {
            if (x + 8 + col < OLED_WIDTH && (bitmap[row * 2 + 1] & (0x80 >> col)))
                OLED_Buffer[page][x + 8 + col] |= (1 << bit);
        }
    }
}

/**
  * @brief  Show a 16x16 Chinese character and refresh display
  */
void OLED_PrintCN16(uint8_t x, uint8_t y, const uint8_t *bitmap)
{
    OLED_ShowCN16(x, y, bitmap);
    OLED_Refresh();
}

/* ====================== 32x32 Chinese Characters =========================== */

/**
  * @brief  32x32 Chinese character bitmaps (128 bytes each)
  *         Format: 32 rows, each row = 4 bytes (32 bits)
  *         MSB = leftmost pixel within each byte.
  *         Generated with SimSun 128px → 32px LANCZOS
  */

/* 柒 — 32x32 SimSun 宋体点阵 */
const uint8_t CN32_QI[128] = {
    0x00,0x80,0x60,0x00, 0x00,0xC0,0x70,0x00,
    0x00,0x60,0x60,0x00, 0x00,0x60,0x60,0x00,
    0x0C,0x00,0x60,0x10, 0x06,0x10,0x60,0x38,
    0x06,0x10,0x21,0xE0, 0x02,0x20,0x7E,0x00,
    0x00,0x60,0xF0,0x00, 0x00,0x4E,0x60,0x00,
    0x00,0xC0,0x20,0x00, 0x07,0x80,0x20,0x10,
    0x01,0x80,0x20,0x10, 0x01,0x80,0x20,0x18,
    0x01,0x80,0x3F,0xB8, 0x01,0x80,0x3F,0xF8,
    0x03,0x81,0x80,0x00, 0x01,0x81,0xC0,0x00,
    0x00,0x01,0x80,0x18, 0x1F,0xF9,0xDF,0xFC,
    0x10,0x07,0xE0,0x00, 0x00,0x07,0xA0,0x00,
    0x00,0x0D,0x90,0x00, 0x00,0x19,0x88,0x00,
    0x00,0x31,0x8C,0x00, 0x00,0x61,0x87,0x00,
    0x00,0xC1,0x81,0xE0, 0x03,0x81,0x80,0xFC,
    0x06,0x01,0x80,0x78, 0x18,0x01,0x80,0x10,
    0x20,0x01,0x80,0x00, 0x00,0x01,0x00,0x00,
};

/* 染 — 32x32 SimSun 宋体点阵 */
const uint8_t CN32_RAN[128] = {
    0x00,0x00,0x80,0x00, 0x03,0x00,0xC0,0x00,
    0x01,0x80,0xC0,0x00, 0x00,0x90,0xC0,0x00,
    0x00,0x90,0xC2,0x00, 0x18,0x27,0xFF,0x00,
    0x0C,0x2C,0xC2,0x00, 0x06,0x40,0xC2,0x00,
    0x06,0x40,0x82,0x00, 0x00,0xC0,0x82,0x00,
    0x00,0x81,0x82,0x00, 0x01,0x81,0x82,0x08,
    0x03,0x03,0x02,0x08, 0x07,0x02,0x02,0x08,
    0x03,0x06,0x03,0x0C, 0x03,0x0C,0x03,0xFC,
    0x03,0x19,0xC1,0xF8, 0x03,0x31,0xC0,0x00,
    0x03,0x41,0x80,0x10, 0x00,0x01,0x80,0x38,
    0x1F,0xFF,0xFF,0xF8, 0x00,0x07,0xC0,0x00,
    0x00,0x0D,0xA0,0x00, 0x00,0x1D,0x90,0x00,
    0x00,0x19,0x88,0x00, 0x00,0x31,0x8E,0x00,
    0x00,0x61,0x87,0x80, 0x01,0xC1,0x81,0xF8,
    0x03,0x01,0x80,0xFC, 0x0E,0x01,0x80,0x30,
    0x18,0x01,0x80,0x00, 0x00,0x01,0x00,0x00,
};

/**
  * @brief  Show a 32x32 Chinese character
  * @param  x:      left column (0 ~ 96)
  * @param  y:      starting page (0 ~ 4), occupies y ~ y+3 (4 pages)
  * @param  bitmap: 128-byte array, 4 bytes per row × 32 rows
  */
void OLED_ShowCN32(uint8_t x, uint8_t y, const uint8_t *bitmap)
{
    uint8_t row, byte_idx, col;
    uint8_t page, bit;

    for (row = 0; row < 32; row++)
    {
        page = y + row / 8;
        bit  = row % 8;

        if (page >= OLED_PAGES)
            continue;

        /* 4 bytes per row = 32 bits */
        for (byte_idx = 0; byte_idx < 4; byte_idx++)
        {
            uint8_t b = bitmap[row * 4 + byte_idx];
            if (b == 0) continue;
            for (col = 0; col < 8; col++)
            {
                if (b & (0x80 >> col))
                {
                    uint8_t px = x + byte_idx * 8 + col;
                    if (px < OLED_WIDTH)
                        OLED_Buffer[page][px] |= (1 << bit);
                }
            }
        }
    }
}

/**
  * @brief  Show a 32x32 Chinese character and refresh display
  */
void OLED_PrintCN32(uint8_t x, uint8_t y, const uint8_t *bitmap)
{
    OLED_ShowCN32(x, y, bitmap);
    OLED_Refresh();
}

/* ========================== Image Support ================================== */

/**
  * @brief  Draw a full-screen 128x64 image (1024 bytes)
  *         Format: page-major, [page0:128bytes, page1:128bytes, ..., page7:128bytes]
  *         Each byte = 8 vertical pixels, LSB = top pixel
  */
void OLED_DrawFullScreen(const uint8_t *bitmap)
{
    uint8_t page, col;
    for (page = 0; page < OLED_PAGES; page++)
    {
        for (col = 0; col < OLED_WIDTH; col++)
        {
            OLED_Buffer[page][col] = bitmap[page * OLED_WIDTH + col];
        }
    }
    OLED_Refresh();
}

/**
  * @brief  Draw a partial image at any position
  * @param  x:      left column
  * @param  y:      top page (0~7)
  * @param  w:      width in pixels
  * @param  h:      height in pages (each page = 8 pixels)
  * @param  bitmap: data with w columns × h pages, same byte format as full-screen
  */
void OLED_DrawImage(uint8_t x, uint8_t y, uint8_t w, uint8_t h, const uint8_t *bitmap)
{
    uint8_t page, col;
    for (page = 0; page < h; page++)
    {
        if (y + page >= OLED_PAGES) break;
        for (col = 0; col < w; col++)
        {
            if (x + col >= OLED_WIDTH) break;
            OLED_Buffer[y + page][x + col] = bitmap[page * w + col];
        }
    }
}
