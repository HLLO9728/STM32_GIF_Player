/**
  ******************************************************************************
  * @file    main.c
  * @brief   ST7789 GIF Player — Hardware SPI + DMA, ping-pong streaming
  *          LCD:  SPI1 @ 36MHz DMA (PA5=SCK, PA7=MOSI, PA2=RES, PA3=DC, PA4=CS)
  *          Flash:SPI2 @ 18MHz DMA FastRead 0x0B (PB13-15, PB12=CS)
  *          UART: PA9=TX, PA10=RX (interrupt ring-buffer for programming)
  ******************************************************************************
  */

#include "stm32f10x.h"
#include "delay.h"
#include "lcd_st7789.h"
#include "w25q64.h"
#include <stdio.h>
#include <string.h>

#define GIF_FLASH_ADDR      0x000000
#define GIF_MAGIC           "GIFB"
#define DMA_CHUNK_SIZE      4096    /* Ping-pong buffer size (bytes) */
#define UART_BAUD           57600
#define RING_SIZE           2048

/* ======================== UART Ring Buffer ================================ */

static volatile uint8_t  uart_ring[RING_SIZE];
static volatile uint32_t uart_head = 0;
static volatile uint32_t uart_tail = 0;

static uint8_t Ring_Read(void)
{
    while (uart_head == uart_tail);
    uint8_t b = uart_ring[uart_tail % RING_SIZE];
    uart_tail++;
    return b;
}

static void Ring_ReadBuf(uint8_t *dst, uint32_t len)
{
    while (len--) *dst++ = Ring_Read();
}

void USART1_IRQHandler(void)
{
    if (USART1->SR & USART_FLAG_RXNE)
    {
        uart_ring[uart_head % RING_SIZE] = (uint8_t)USART1->DR;
        uart_head++;
    }
    if (USART1->SR & (USART_FLAG_ORE | USART_FLAG_FE | USART_FLAG_NE))
    {
        (void)USART1->DR;
        (void)USART1->SR;
    }
}

/* ======================== UART Helpers ==================================== */

static void UART1_Init(uint32_t baud)
{
    GPIO_InitTypeDef gpio;
    USART_InitTypeDef usart;
    NVIC_InitTypeDef  nvic;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_USART1, ENABLE);

    gpio.GPIO_Pin   = GPIO_Pin_9;
    gpio.GPIO_Mode  = GPIO_Mode_AF_PP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpio);

    gpio.GPIO_Pin   = GPIO_Pin_10;
    gpio.GPIO_Mode  = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &gpio);

    USART_StructInit(&usart);
    usart.USART_BaudRate            = baud;
    usart.USART_WordLength          = USART_WordLength_8b;
    usart.USART_StopBits            = USART_StopBits_1;
    usart.USART_Parity              = USART_Parity_No;
    usart.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    usart.USART_Mode                = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &usart);

    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    nvic.NVIC_IRQChannel    = USART1_IRQn;
    nvic.NVIC_IRQChannelPreemptionPriority = 0;
    nvic.NVIC_IRQChannelSubPriority        = 0;
    nvic.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvic);
    USART_Cmd(USART1, ENABLE);
}

/* =========================== LCD Helpers ================================== */

static void LCD_ShowCentered(uint8_t row, const char *str, uint16_t fg, uint16_t bg)
{
    uint8_t len = 0;
    while (str[len]) len++;
    uint16_t x = (LCD_WIDTH - len * 8) / 2;
    LCD_ShowString(x, row * 16, str, fg, bg);
}

static void LCD_ClearRow(uint8_t row, uint16_t bg)
{
    LCD_Fill(0, row * 16, LCD_WIDTH - 1, row * 16 + 15, bg);
}

/* ==================== W25Q64 DMA Helpers (non-blocking) =================== */

/* Start fast-read DMA (does NOT wait). Call W25Q_DMA_Wait() after. */
/* ======================== GIF Player ====================================== */

/* Frame streaming buffer (4KB in BSS) */
static uint8_t  dma_bufA[DMA_CHUNK_SIZE];

typedef struct {
    uint16_t width;
    uint16_t height;
    uint16_t frame_count;
    uint16_t delay_ms;
    uint32_t bytes_per_frame;
} GIF_Header;

static GIF_Header GIF_ReadHeader(void)
{
    GIF_Header hdr;
    uint8_t buf[16];
    W25Q_Read(GIF_FLASH_ADDR, buf, 16);
    hdr.width           = buf[5]  | ((uint16_t)buf[6]  << 8);
    hdr.height          = buf[7]  | ((uint16_t)buf[8]  << 8);
    hdr.frame_count     = buf[9]  | ((uint16_t)buf[10] << 8);
    hdr.delay_ms        = buf[11] | ((uint16_t)buf[12] << 8);
    hdr.bytes_per_frame = (uint32_t)hdr.width * hdr.height * 2;
    return hdr;
}

static void GIF_PlayLoop(void)
{
    GIF_Header hdr = GIF_ReadHeader();
    uint16_t   frame;
    char       buf[32];

    LCD_Clear(COLOR_BLACK);
    LCD_DrawFillRect(0, 0, LCD_WIDTH, 30, COLOR_GREEN);
    LCD_ShowCentered(0, "GIF Playing!", COLOR_WHITE, COLOR_GREEN);
    sprintf(buf, "%ux%u  %u fr  %ums", hdr.width, hdr.height, hdr.frame_count, hdr.delay_ms);
    LCD_ShowCentered(10, buf, COLOR_CYAN, COLOR_BLACK);
    Delay_ms(1000);

    while (1)
    {
        for (frame = 0; frame < hdr.frame_count; frame++)
        {
            uint32_t frame_addr = GIF_FLASH_ADDR + 16
                                + (uint32_t)frame * hdr.bytes_per_frame;
            uint32_t remaining  = hdr.bytes_per_frame;
            uint32_t offset     = 0;

            LCD_SetWindow(0, 0, hdr.width - 1, hdr.height - 1);
            LCD_StreamStart();

            while (remaining > 0)
            {
                uint32_t chunk = (remaining > DMA_CHUNK_SIZE) ? DMA_CHUNK_SIZE : remaining;
                W25Q_FastRead_DMA(frame_addr + offset, dma_bufA, chunk);
                LCD_StreamSend(dma_bufA, chunk);
                offset    += chunk;
                remaining -= chunk;
            }

            LCD_StreamEnd();
            if (hdr.delay_ms > 0) Delay_ms(hdr.delay_ms);
        }
    }
}

/* ======================== UART Programming Mode =========================== */

static void EnterProgrammingMode(void)
{
    uint8_t  header[16];
    uint32_t total_size, bytes_done, sectors, s;
    uint16_t frame_count, width, height;
    uint8_t  page_buf[256];
    char     buf[40];
    uint8_t  last_pct, pct;

    /* ---- Step 1: Erase ---- */
    LCD_Clear(COLOR_BLACK);
    LCD_DrawFillRect(0, 0, LCD_WIDTH, 30, COLOR_ORANGE);
    LCD_ShowCentered(0, "ERASING FLASH...", COLOR_WHITE, COLOR_ORANGE);
    LCD_ShowString(8, 70, "Do NOT send data yet!", COLOR_RED, COLOR_BLACK);

    sectors = 800;
    for (s = 0; s < sectors; s++)
    {
        W25Q_EraseSector(s * 4096);
        if (s % 20 == 0 || s == sectors - 1)
        {
            pct = (uint8_t)((s + 1) * 100 / sectors);
            sprintf(buf, "Erase: %u%% (%lu/%lu)", pct, s + 1, sectors);
            LCD_ClearRow(5, COLOR_BLACK);
            LCD_ShowString(8, 5 * 16, buf, COLOR_YELLOW, COLOR_BLACK);
        }
    }

    /* ---- Step 2: Ready ---- */
    LCD_Clear(COLOR_BLACK);
    LCD_DrawFillRect(0, 0, LCD_WIDTH, 30, COLOR_GREEN);
    LCD_ShowCentered(0, "READY - SEND FILE", COLOR_WHITE, COLOR_GREEN);
    LCD_ShowString(8,  50, "COM4  57600 8N1",      COLOR_WHITE, COLOR_BLACK);
    LCD_ShowString(8,  70, "Send: gif_data.bin",    COLOR_YELLOW, COLOR_BLACK);

    UART1_Init(UART_BAUD);

    /* ---- Step 3: Search for "GIFB\x00" ---- */
    {
        uint8_t  ring[5] = {0,0,0,0,0};
        uint32_t scanned = 0;
        while (1)
        {
            uint8_t b = Ring_Read();
            scanned++;
            ring[0]=ring[1]; ring[1]=ring[2]; ring[2]=ring[3]; ring[3]=ring[4]; ring[4]=b;
            if (ring[0]=='G' && ring[1]=='I' && ring[2]=='F' && ring[3]=='B' && ring[4]==0x00)
                break;
            if (scanned % 512 == 0)
            {
                sprintf(buf, "Scan %lu B...", scanned);
                LCD_ClearRow(9, COLOR_BLACK);
                LCD_ShowString(8, 9*16, buf, COLOR_LIGHTGRAY, COLOR_BLACK);
            }
        }
        header[0]='G'; header[1]='I'; header[2]='F'; header[3]='B'; header[4]=0x00;
        Ring_ReadBuf(header + 5, 11);
    }

    /* Parse header */
    width       = header[5]  | ((uint16_t)header[6]  << 8);
    height      = header[7]  | ((uint16_t)header[8]  << 8);
    frame_count = header[9]  | ((uint16_t)header[10] << 8);
    total_size  = 16 + (uint32_t)frame_count * width * height * 2;

    LCD_Clear(COLOR_BLACK);
    LCD_DrawFillRect(0, 0, LCD_WIDTH, 30, COLOR_BLUE);
    LCD_ShowCentered(0, "RECEIVING...", COLOR_WHITE, COLOR_BLUE);
    sprintf(buf, "%ux%u  %u fr  %lu KB", width, height, frame_count, total_size/1024);
    LCD_ShowString(8, 50, buf, COLOR_WHITE, COLOR_BLACK);

    /* ---- Step 4: Write first page ---- */
    {
        uint8_t first[256];
        memcpy(first, header, 16);
        Ring_ReadBuf(first + 16, 240);
        W25Q_WritePage(0, first, 256);
        bytes_done = 256;
    }
    last_pct = 0;

    /* ---- Step 5: Receive + write ---- */
    while (bytes_done < total_size)
    {
        uint16_t chunk = (total_size - bytes_done >= 256) ? 256
                       : (uint16_t)(total_size - bytes_done);
        Ring_ReadBuf(page_buf, chunk);
        W25Q_WritePage(bytes_done, page_buf, chunk);
        bytes_done += chunk;

        pct = (uint8_t)(bytes_done * 100 / total_size);
        if (pct != last_pct)
        {
            last_pct = pct;
            sprintf(buf, "%u%%  %lu/%lu KB", pct, bytes_done/1024, total_size/1024);
            LCD_ClearRow(5, COLOR_BLACK);
            LCD_ShowString(8, 5*16, buf, COLOR_GREEN, COLOR_BLACK);
            uint16_t bar_w = (uint16_t)((uint32_t)pct * 200 / 100);
            LCD_DrawFillRect(20, 100, 200, 15, COLOR_DARKGRAY);
            if (bar_w > 0) LCD_DrawFillRect(20, 100, bar_w, 15, COLOR_GREEN);
            LCD_DrawRect(20, 100, 200, 15, COLOR_WHITE);
        }
    }

    /* ---- Verify ---- */
    {
        uint8_t verify[5];
        W25Q_Read(0, verify, 5);
        LCD_Clear(COLOR_BLACK);
        if (memcmp(verify, "GIFB\x00", 5) == 0)
        {
            LCD_DrawFillRect(0, 0, LCD_WIDTH, 30, COLOR_GREEN);
            LCD_ShowCentered(0, "SUCCESS!", COLOR_WHITE, COLOR_GREEN);
            sprintf(buf, "%lu KB written", total_size/1024);
            LCD_ShowCentered(6, buf, COLOR_WHITE, COLOR_BLACK);
            LCD_ShowCentered(8, "Reset to play GIF!", COLOR_YELLOW, COLOR_BLACK);
        }
        else
        {
            LCD_DrawFillRect(0, 0, LCD_WIDTH, 30, COLOR_RED);
            LCD_ShowCentered(0, "WRITE FAILED", COLOR_WHITE, COLOR_RED);
            sprintf(buf, "Got %lu/%lu KB", bytes_done/1024, total_size/1024);
            LCD_ShowCentered(7, buf, COLOR_WHITE, COLOR_BLACK);
        }
    }
    while (1);
}

/* ============================ Main ======================================== */

int main(void)
{
    uint8_t magic[5];
    int     force_prog = 0;

    Delay_Init();
    W25Q_Init();
    LCD_Init();

    /* Check PA15: grounded = force programming mode */
    {
        GPIO_InitTypeDef gpio;
        gpio.GPIO_Pin  = GPIO_Pin_15;
        gpio.GPIO_Mode = GPIO_Mode_IPU;
        gpio.GPIO_Speed = GPIO_Speed_2MHz;
        GPIO_Init(GPIOA, &gpio);
        Delay_ms(1);
        if (!GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_15))
            force_prog = 1;
    }

    LCD_Clear(COLOR_BLACK);
    LCD_DrawFillRect(0, 0, LCD_WIDTH, 30, COLOR_BLUE);
    LCD_ShowCentered(0, "STM32 GIF Player", COLOR_WHITE, COLOR_BLUE);

    if (force_prog)
    {
        LCD_ShowCentered(4, "PA15=GND -> Prog mode", COLOR_ORANGE, COLOR_BLACK);
        Delay_ms(1500);
        EnterProgrammingMode();
    }

    LCD_ShowCentered(5, "SPI1@36M SPI2@18M DMA", COLOR_CYAN, COLOR_BLACK);
    LCD_ShowCentered(8, "Checking flash...", COLOR_YELLOW, COLOR_BLACK);
    Delay_ms(500);

    W25Q_Read(GIF_FLASH_ADDR, magic, 5);

    if (memcmp(magic, GIF_MAGIC "\x00", 5) == 0)
    {
        LCD_ClearRow(8, COLOR_BLACK);
        LCD_ShowCentered(8, "GIF found! Playing...", COLOR_GREEN, COLOR_BLACK);
        Delay_ms(1000);
        GIF_PlayLoop();
    }
    else
    {
        LCD_ClearRow(8, COLOR_BLACK);
        LCD_ShowCentered(8, "No GIF. Prog mode...", COLOR_ORANGE, COLOR_BLACK);
        Delay_ms(1000);
        EnterProgrammingMode();
    }

    while (1);
}
