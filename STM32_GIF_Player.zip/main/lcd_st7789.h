/**
  ******************************************************************************
  * @file    lcd_st7789.h
  * @brief   1.54-inch IPS LCD driver (ST7789V, 240x240, RGB565)
  *          Hardware SPI1 @ 36MHz + DMA: PA5=SCK, PA7=MOSI
  *          GPIO: PA2=RES, PA3=DC, PA4=CS, PA8=BLK(TIM1_PWM)
  ******************************************************************************
  */

#ifndef __LCD_ST7789_H
#define __LCD_ST7789_H

#include "stm32f10x.h"

/* =========================== LCD Resolution =============================== */
#define LCD_WIDTH   240
#define LCD_HEIGHT  240

/* ============================ RGB565 Colors =============================== */
#define COLOR_BLACK       0x0000
#define COLOR_WHITE       0xFFFF
#define COLOR_RED         0xF800
#define COLOR_GREEN       0x07E0
#define COLOR_BLUE        0x001F
#define COLOR_YELLOW      0xFFE0
#define COLOR_CYAN        0x07FF
#define COLOR_MAGENTA     0xF81F
#define COLOR_GRAY        0x8430
#define COLOR_DARKGRAY    0x4208
#define COLOR_LIGHTGRAY   0xC618
#define COLOR_ORANGE      0xFD20
#define COLOR_PURPLE      0x8010
#define COLOR_BROWN       0xA145
#define COLOR_PINK        0xFE19

#define RGB565(r, g, b)   ((((r) & 0xF8) << 8) | (((g) & 0xFC) << 3) | ((b) >> 3))

/* ============================== Public API ================================ */

void LCD_Init(void);

/* ---- Drawing Primitives (software SPI — for status UI, not speed critical) ---- */
void LCD_SetWindow(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2);
void LCD_Fill(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color);
void LCD_Clear(uint16_t color);
void LCD_DrawRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color);
void LCD_DrawFillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color);
void LCD_DrawLine(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color);

/* ---- Text ---- */
void LCD_ShowString(uint16_t x, uint16_t y, const char *str, uint16_t fg, uint16_t bg);

/* ---- DMA burst stream (hardware SPI @ 36MHz, for GIF frames) ---- */
void LCD_StreamStart(void);                       /* CS=0, DC=1, SPI1 ready */
void LCD_StreamSend(const uint8_t *data, uint32_t len);       /* DMA: bytes → LCD */
void LCD_StreamEnd(void);                         /* Wait DMA done, CS=1 */

/* ---- Backlight ---- */
void LCD_Backlight(uint8_t duty);

#endif /* __LCD_ST7789_H */
