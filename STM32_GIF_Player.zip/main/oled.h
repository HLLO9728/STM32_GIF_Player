/**
  ******************************************************************************
  * @file    oled.h
  * @brief   SSD1306 OLED driver header (Software I2C: PA6=SCL, PA7=SDA)
  ******************************************************************************
  */

#ifndef __OLED_H
#define __OLED_H

#include "stm32f10x.h"

/* OLED resolution */
#define OLED_WIDTH   128
#define OLED_HEIGHT  64
#define OLED_PAGES   (OLED_HEIGHT / 8)

extern uint8_t OLED_Buffer[OLED_PAGES][OLED_WIDTH];

/* I2C pins */
#define OLED_SCL_PIN  GPIO_Pin_6
#define OLED_SDA_PIN  GPIO_Pin_7
#define OLED_PORT     GPIOA
#define OLED_RCC      RCC_APB2Periph_GPIOA

/* SSD1306 I2C address (7-bit: 0x3C, 8-bit write: 0x78) */
#define OLED_ADDR     0x78

/**
  * @brief  Initialize OLED display
  */
void OLED_Init(void);

/**
  * @brief  Clear entire display (buffer only)
  */
void OLED_Clear(void);

/**
  * @brief  Flush buffer to OLED (full screen refresh)
  */
void OLED_Refresh(void);

/**
  * @brief  Show a character at pixel position
  * @param  x: column (0 ~ 127)
  * @param  y: row (0 ~ 7, each row = 8 pixels high)
  * @param  ch: ASCII character to display
  */
void OLED_ShowChar(uint8_t x, uint8_t y, char ch);

/**
  * @brief  Show a string starting at pixel position
  * @param  x: starting column (0 ~ 127)
  * @param  y: row (0 ~ 7, each row = 8 pixels high)
  * @param  str: pointer to null-terminated string
  */
void OLED_ShowString(uint8_t x, uint8_t y, const char *str);

/**
  * @brief  Display a single-page (8-pixel high) string at (x, y)
  *         with automatic line wrapping. Convenience function.
  */
void OLED_Print(uint8_t x, uint8_t y, const char *str);

/**
  * @brief  Draw a single pixel at (x, y)
  * @param  x: 0 ~ 127
  * @param  y: 0 ~ 63
  * @param  color: 1 = white, 0 = black
  */
void OLED_DrawPixel(uint8_t x, uint8_t y, uint8_t color);

/* ---- 16x16 Chinese Character Support ---- */

void OLED_ShowCN16(uint8_t x, uint8_t y, const uint8_t *bitmap);
void OLED_PrintCN16(uint8_t x, uint8_t y, const uint8_t *bitmap);

extern const uint8_t CN_QI[];   /* 柒 16x16 */
extern const uint8_t CN_RAN[];  /* 染 16x16 */

/* ---- 32x32 Chinese Character Support ---- */

/**
  * @brief  Show a 32x32 Chinese character (4 pages high, 32px wide)
  * @param  x:      left column (0 ~ 96)
  * @param  y:      starting page (0 ~ 4), occupies pages y ~ y+3
  * @param  bitmap: 128-byte array [row0_b0..b3, row1_b0..b3, ..., row31_b0..b3]
  *                 each row = 4 bytes (32 bits), MSB = leftmost pixel
  */
void OLED_ShowCN32(uint8_t x, uint8_t y, const uint8_t *bitmap);

void OLED_PrintCN32(uint8_t x, uint8_t y, const uint8_t *bitmap);

extern const uint8_t CN32_QI[];   /* 柒 32x32 */
extern const uint8_t CN32_RAN[];  /* 染 32x32 */

/* ---- Image Support ---- */

/**
  * @brief  Draw a full-screen 128x64 monochrome image
  * @param  bitmap: 1024-byte array, SSD1306 page-column format
  *                 [page0_col0, page0_col1, ..., page0_col127,
  *                  page1_col0, ..., page7_col127]
  *                 each byte: bit0 = top pixel of that column, bit7 = bottom
  */
void OLED_DrawFullScreen(const uint8_t *bitmap);

/**
  * @brief  Draw an image of arbitrary size at any position
  * @param  x:      left column (0 ~ 127)
  * @param  y:      top page (0 ~ 7)
  * @param  w:      width in pixels (1 ~ 128)
  * @param  h:      height in pages (1 ~ 8), each page = 8 pixels
  * @param  bitmap: data array, same format as full-screen but w×h pages
  */
void OLED_DrawImage(uint8_t x, uint8_t y, uint8_t w, uint8_t h, const uint8_t *bitmap);

#endif /* __OLED_H */
