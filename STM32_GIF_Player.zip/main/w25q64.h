/**
  ******************************************************************************
  * @file    w25q64.h
  * @brief   W25Q64 8MB SPI Flash driver
  *          SPI2: PB13=SCK, PB14=MISO, PB15=MOSI, PB12=CS
  ******************************************************************************
  */

#ifndef __W25Q64_H
#define __W25Q64_H

#include "stm32f10x.h"

/* W25Q64 specs */
#define W25Q64_SIZE         (8 * 1024 * 1024)  /* 8MB */
#define W25Q64_SECTOR_SIZE  4096               /* 4KB per sector */
#define W25Q64_PAGE_SIZE    256                /* 256 bytes per page */

void W25Q_Init(void);
uint32_t W25Q_ReadID(void);
void W25Q_Read(uint32_t addr, uint8_t *buf, uint32_t len);
void W25Q_FastRead_DMA(uint32_t addr, uint8_t *buf, uint32_t len); /* 0x0B + DMA */
void W25Q_WritePage(uint32_t addr, const uint8_t *buf, uint16_t len);
void W25Q_EraseSector(uint32_t addr);
void W25Q_EraseChip(void);

#endif /* __W25Q64_H */
