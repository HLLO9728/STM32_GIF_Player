/**
  ******************************************************************************
  * @file    w25q64.c
  * @brief   W25Q64 SPI Flash driver
  *          PB12=CS, PB13=SCK, PB14=MISO, PB15=MOSI
  ******************************************************************************
  */

#include "w25q64.h"

/* ---- W25Q64 Commands ---- */
#define CMD_WRITE_ENABLE    0x06
#define CMD_READ_STATUS     0x05
#define CMD_READ_DATA       0x03
#define CMD_PAGE_PROGRAM    0x02
#define CMD_SECTOR_ERASE    0x20
#define CMD_CHIP_ERASE      0xC7
#define CMD_JEDEC_ID        0x9F

/* ---- Pin defines (SPI2 + PB12 CS) ---- */
#define CS_PORT  GPIOB
#define CS_PIN   GPIO_Pin_12
#define CS_LOW()  GPIO_ResetBits(CS_PORT, CS_PIN)
#define CS_HIGH() GPIO_SetBits(CS_PORT, CS_PIN)

/* ---- SPI byte exchange ---- */
static uint8_t SPI2_Swap(uint8_t dat)
{
    /* Wait TX empty, send */
    while (!(SPI2->SR & SPI_I2S_FLAG_TXE));
    SPI2->DR = dat;
    /* Wait RX done, return */
    while (!(SPI2->SR & SPI_I2S_FLAG_RXNE));
    return (uint8_t)SPI2->DR;
}

/* ---- Wait for flash to finish internal operation ---- */
static void W25Q_WaitBusy(void)
{
    CS_LOW();
    SPI2_Swap(CMD_READ_STATUS);
    while (SPI2_Swap(0xFF) & 0x01);  /* BUSY bit = 1 → still working */
    CS_HIGH();
}

/* ---- Enable write ---- */
static void W25Q_WriteEnable(void)
{
    CS_LOW();
    SPI2_Swap(CMD_WRITE_ENABLE);
    CS_HIGH();
}

/* ======================== Public API ================================= */

/**
  * @brief  Initialize SPI2 + CS pin
  */
void W25Q_Init(void)
{
    GPIO_InitTypeDef gpio;
    SPI_InitTypeDef   spi;

    /* Clock: SPI2 on APB1, GPIOB on APB2 */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

    /* PB13=SCK, PB15=MOSI: push-pull output */
    gpio.GPIO_Pin   = GPIO_Pin_13 | GPIO_Pin_15;
    gpio.GPIO_Mode  = GPIO_Mode_AF_PP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &gpio);

    /* PB14=MISO: floating input */
    gpio.GPIO_Pin   = GPIO_Pin_14;
    gpio.GPIO_Mode  = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOB, &gpio);

    /* PB12=CS: push-pull output, high by default */
    gpio.GPIO_Pin   = CS_PIN;
    gpio.GPIO_Mode  = GPIO_Mode_Out_PP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(CS_PORT, &gpio);
    CS_HIGH();

    /* SPI2 config: Master, 18MHz (36MHz/2), Mode0 */
    spi.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
    spi.SPI_Mode      = SPI_Mode_Master;
    spi.SPI_DataSize  = SPI_DataSize_8b;
    spi.SPI_CPOL      = SPI_CPOL_Low;
    spi.SPI_CPHA      = SPI_CPHA_1Edge;
    spi.SPI_NSS       = SPI_NSS_Soft;
    spi.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_2;  /* 18MHz */
    spi.SPI_FirstBit  = SPI_FirstBit_MSB;
    SPI_Init(SPI2, &spi);
    SPI_Cmd(SPI2, ENABLE);

    /* DMA1_Channel4: SPI2_RX, DMA1_Channel5: SPI2_TX (for FastRead DMA) */
    {
        DMA_InitTypeDef dma;
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

        /* Ch4 = SPI2 RX */
        DMA_DeInit(DMA1_Channel4);
        dma.DMA_PeripheralBaseAddr = (uint32_t)&SPI2->DR;
        dma.DMA_MemoryBaseAddr     = 0;
        dma.DMA_DIR                = DMA_DIR_PeripheralSRC;  /* SPI → Mem */
        dma.DMA_BufferSize         = 0;
        dma.DMA_PeripheralInc      = DMA_PeripheralInc_Disable;
        dma.DMA_MemoryInc          = DMA_MemoryInc_Enable;
        dma.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
        dma.DMA_MemoryDataSize     = DMA_MemoryDataSize_Byte;
        dma.DMA_Mode               = DMA_Mode_Normal;
        dma.DMA_Priority           = DMA_Priority_High;
        dma.DMA_M2M                = DMA_M2M_Disable;
        DMA_Init(DMA1_Channel4, &dma);

        /* Ch5 = SPI2 TX (dummy bytes for clock, MINC disabled) */
        DMA_DeInit(DMA1_Channel5);
        dma.DMA_DIR                = DMA_DIR_PeripheralDST;  /* Mem → SPI */
        dma.DMA_MemoryInc          = DMA_MemoryInc_Disable;   /* Send same byte */
        DMA_Init(DMA1_Channel5, &dma);
    }
}

/**
  * @brief  Read JEDEC ID: should return 0xEF4017
  */
uint32_t W25Q_ReadID(void)
{
    uint32_t id = 0;
    CS_LOW();
    SPI2_Swap(CMD_JEDEC_ID);
    id |= (uint32_t)SPI2_Swap(0xFF) << 16;  /* Manufacturer */
    id |= (uint32_t)SPI2_Swap(0xFF) << 8;   /* Type */
    id |= (uint32_t)SPI2_Swap(0xFF);        /* Capacity */
    CS_HIGH();
    return id;
}

/**
  * @brief  Read data from flash to buffer
  */
void W25Q_Read(uint32_t addr, uint8_t *buf, uint32_t len)
{
    CS_LOW();
    SPI2_Swap(CMD_READ_DATA);
    SPI2_Swap((addr >> 16) & 0xFF);   /* Address [23:16] */
    SPI2_Swap((addr >> 8)  & 0xFF);   /* Address [15:8] */
    SPI2_Swap( addr        & 0xFF);   /* Address [7:0] */
    while (len--)
        *buf++ = SPI2_Swap(0xFF);
    CS_HIGH();
}

/**
  * @brief  Write one page (max 256 bytes) at address
  *         Address must be within same page
  */
void W25Q_WritePage(uint32_t addr, const uint8_t *buf, uint16_t len)
{
    if (len == 0 || len > 256) return;

    W25Q_WriteEnable();
    CS_LOW();
    SPI2_Swap(CMD_PAGE_PROGRAM);
    SPI2_Swap((addr >> 16) & 0xFF);
    SPI2_Swap((addr >> 8)  & 0xFF);
    SPI2_Swap( addr        & 0xFF);
    while (len--)
        SPI2_Swap(*buf++);
    CS_HIGH();
    W25Q_WaitBusy();
}

/**
  * @brief  Erase one 4KB sector
  */
void W25Q_EraseSector(uint32_t addr)
{
    W25Q_WriteEnable();
    CS_LOW();
    SPI2_Swap(CMD_SECTOR_ERASE);
    SPI2_Swap((addr >> 16) & 0xFF);
    SPI2_Swap((addr >> 8)  & 0xFF);
    SPI2_Swap( addr        & 0xFF);
    CS_HIGH();
    W25Q_WaitBusy();
}

/**
  * @brief  Erase entire chip (slow, ~40 seconds!)
  */
void W25Q_EraseChip(void)
{
    W25Q_WriteEnable();
    CS_LOW();
    SPI2_Swap(CMD_CHIP_ERASE);
    CS_HIGH();
    W25Q_WaitBusy();
}

/**
  * @brief  Read with DMA — 0x03 regular read (same as polling), 18MHz
  *         Command+address via SPI2_Swap (clean RX every byte, no ORE).
  *         Data phase via SPI2 TX DMA (clock) + RX DMA (capture).
  */
void W25Q_FastRead_DMA(uint32_t addr, uint8_t *buf, uint32_t len)
{
    static const uint8_t dummy = 0xFF;

    if (len == 0) return;

    CS_LOW();

    /* ---- Phase 1: command + address via SPI2_Swap (same as polling read) ---- */
    SPI2_Swap(0x03);                        /* Regular read (no dummy byte) */
    SPI2_Swap((uint8_t)(addr >> 16));
    SPI2_Swap((uint8_t)(addr >> 8));
    SPI2_Swap((uint8_t)(addr));

    /* Now SPI is idle: TX empty, RX empty, BSY=0, no ORE set */

    /* ---- Phase 2: data via DMA ---- */
    DMA_Cmd(DMA1_Channel4, DISABLE);
    DMA1_Channel4->CMAR  = (uint32_t)buf;
    DMA1_Channel4->CNDTR = len;

    DMA_Cmd(DMA1_Channel5, DISABLE);
    DMA1_Channel5->CMAR  = (uint32_t)&dummy;
    DMA1_Channel5->CNDTR = len;

    SPI_I2S_DMACmd(SPI2, SPI_I2S_DMAReq_Rx, ENABLE);
    SPI_I2S_DMACmd(SPI2, SPI_I2S_DMAReq_Tx, ENABLE);

    DMA_Cmd(DMA1_Channel4, ENABLE);  /* RX ready first */
    DMA_Cmd(DMA1_Channel5, ENABLE);  /* TX starts clock */

    while (!DMA_GetFlagStatus(DMA1_FLAG_TC4));
    while (!DMA_GetFlagStatus(DMA1_FLAG_TC5));

    DMA_Cmd(DMA1_Channel4, DISABLE);
    DMA_Cmd(DMA1_Channel5, DISABLE);
    SPI_I2S_DMACmd(SPI2, SPI_I2S_DMAReq_Rx, DISABLE);
    SPI_I2S_DMACmd(SPI2, SPI_I2S_DMAReq_Tx, DISABLE);
    DMA_ClearFlag(DMA1_FLAG_TC4);
    DMA_ClearFlag(DMA1_FLAG_TC5);

    while (SPI2->SR & SPI_I2S_FLAG_BSY);
    CS_HIGH();
}
