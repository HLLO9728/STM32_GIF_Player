/**
  ******************************************************************************
  * @file    delay.c
  * @brief   SysTick-based millisecond delay
  *          SysCLK = 72MHz  →  1ms = 72000 ticks
  ******************************************************************************
  */

#include "delay.h"

static volatile uint32_t g_ms;  /* millisecond counter */

/**
  * @brief  Initialize SysTick for 1ms interval
  *         Called once at startup.
  */
void Delay_Init(void)
{
    /* SysTick reload value: 1ms = SystemCoreClock / 1000 */
    if (SysTick_Config(SystemCoreClock / 1000))
    {
        /* Reload value out of range — should never happen at 72MHz */
        while (1);
    }
}

/**
  * @brief  Blocking delay in milliseconds
  * @param  ms: delay time (1 ~ 4294967295)
  */
void Delay_ms(uint32_t ms)
{
    uint32_t target = g_ms + ms;
    while (g_ms < target);
}

/**
  * @brief  SysTick interrupt handler (1ms tick)
  *         Increments the global millisecond counter.
  */
void SysTick_Handler(void)
{
    g_ms++;
}
