/**
  ******************************************************************************
  * @file    delay.h
  * @brief   Millisecond delay using SysTick timer
  *          HSE = 8MHz, SYSCLK = 72MHz
  ******************************************************************************
  */

#ifndef __DELAY_H
#define __DELAY_H

#include "stm32f10x.h"

void Delay_Init(void);
void Delay_ms(uint32_t ms);

#endif /* __DELAY_H */
