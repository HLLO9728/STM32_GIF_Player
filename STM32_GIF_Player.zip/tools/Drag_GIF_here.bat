@echo off
chcp 65001 >nul
title GIF 转换器

if "%~1"=="" (
    echo 用法：把 GIF 文件拖拽到这个 bat 图标上
    echo 或者：gif2bin.py 输入.gif 输出.bin
    pause
    exit /b
)

echo 正在转换: %~1
echo.
python "%~dp0gif2bin.py" "%~1" "%~dp0gif_data.bin"
echo.
echo ==============================
echo 转换完成！文件保存在:
echo %~dp0gif_data.bin
echo.
echo 接下来:
echo 1. 板子 PA15 接 GND 后上电
echo 2. 等待 LCD 显示 "READY - SEND FILE"
echo 3. 串口工具 57600 发送 gif_data.bin（二进制模式）
echo 4. 复位即可播放
echo ==============================
pause
