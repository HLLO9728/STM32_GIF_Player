"""
gif2bin.py — Convert GIF to RGB565 binary
Uses imageio for correct GIF frame compositing (no manual alpha hacks).
Usage: python gif2bin.py input.gif output.bin
"""

import sys
import numpy as np
import imageio


def rgb_to_rgb565(r, g, b):
    return ((int(r) & 0xF8) << 8) | ((int(g) & 0xFC) << 3) | (int(b) >> 3)


def convert_gif(input_path, output_path):
    # Read GIF with imageio v2 API — correctly handles compositing/transparency
    reader = imageio.get_reader(input_path)
    frames_np = [frame for frame in reader]  # Each is a numpy array (H, W, 3) or (H, W, 4)
    delays = [reader.get_meta_data(i).get("duration", 40) for i in range(len(frames_np))]
    reader.close()

    frame_count = len(frames_np)
    height, width = frames_np[0].shape[:2]

    print(f"Frames: {frame_count}")
    print(f"Size: {width}x{height}")

    if width != 240 or height != 240:
        print(f"WARNING: resizing {width}x{height} -> 240x240")

    uniform_delay = max(set(delays), key=delays.count)
    print(f"Delay: {uniform_delay}ms per frame")
    bytes_per_frame = 240 * 240 * 2
    print(f"Total data: {frame_count * bytes_per_frame / 1024:.1f} KB")

    with open(output_path, "wb") as f:
        # Header (16 bytes)
        f.write(b"GIFB\x00")
        f.write((240).to_bytes(2, "little"))          # width
        f.write((240).to_bytes(2, "little"))          # height
        f.write(frame_count.to_bytes(2, "little"))    # frames
        f.write(uniform_delay.to_bytes(2, "little"))  # delay
        f.write(b"\x00" * 3)                          # padding

        for idx, frame in enumerate(frames_np):
            # Resize if needed
            if frame.shape[1] != 240 or frame.shape[0] != 240:
                from PIL import Image
                img = Image.fromarray(frame)
                img = img.resize((240, 240), Image.LANCZOS)
                frame = np.array(img)

            # Convert to RGB565
            for y in range(240):
                row = bytearray(480)
                for x in range(240):
                    pixel = frame[y, x]
                    if len(pixel) >= 3:
                        r, g, b = pixel[0], pixel[1], pixel[2]
                    else:
                        r = g = b = pixel[0]  # Grayscale
                    rgb565 = rgb_to_rgb565(r, g, b)
                    row[x * 2]     = (rgb565 >> 8) & 0xFF
                    row[x * 2 + 1] = rgb565 & 0xFF
                f.write(row)

            if (idx + 1) % 5 == 0:
                print(f"  Converted frame {idx + 1}/{frame_count}")

    print(f"\nDone! Saved to: {output_path}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python gif2bin.py input.gif [output.bin]")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else input_file.rsplit(".", 1)[0] + ".bin"
    convert_gif(input_file, output_file)
