"""
send_bin.py — Send a binary file to STM32 via UART for W25Q64 programming
Usage: python send_bin.py <bin_file> <com_port> [baud_rate]

Protocol:
  1. Wait for "READY" from STM32
  2. Send file size (4 bytes, uint32 LE)
  3. Wait for "ERASE_OK"
  4. Send raw binary data in 256-byte chunks
  5. Wait for "DONE"
"""

import sys
import time
import struct


def send_bin(bin_file, port, baud=115200):
    import serial

    data = open(bin_file, "rb").read()
    file_size = len(data)
    print(f"File: {bin_file}")
    print(f"Size: {file_size:,} bytes ({file_size/1024:.1f} KB)")
    print(f"Port: {port} @ {baud} baud")
    print()

    ser = serial.Serial(port, baud, timeout=5)
    ser.reset_input_buffer()

    # 1. Wait for READY
    print("Waiting for STM32...", end=" ", flush=True)
    line = ser.readline()
    if b"READY" not in line:
        print(f"\nERROR: Expected READY, got: {line}")
        ser.close()
        return
    print("connected!")

    # 2. Send file size
    ser.write(struct.pack("<I", file_size))
    ser.flush()
    print(f"Sent size: {file_size}")

    # 3. Wait for ERASE_OK
    line = ser.readline()
    if b"ERASE_OK" not in line:
        print(f"ERROR: Expected ERASE_OK, got: {line}")
        ser.close()
        return
    print("Erase done, sending data...")

    # 4. Send data in chunks
    chunk_size = 256  # W25Q64 page size
    total_sent = 0
    start_time = time.time()

    for offset in range(0, file_size, chunk_size):
        chunk = data[offset : offset + chunk_size]
        ser.write(chunk)
        total_sent += len(chunk)

        # Show progress every ~1%
        pct = total_sent * 100 // file_size
        elapsed = time.time() - start_time
        if pct > (total_sent - chunk_size) * 100 // file_size or pct % 5 == 0:
            eta = (elapsed / total_sent * (file_size - total_sent)) if total_sent > 0 else 0
            print(f"\r  Progress: {pct}%  ({total_sent/1024:.0f}/{file_size/1024:.0f} KB)  "
                  f"Elapsed: {elapsed:.0f}s  ETA: {eta:.0f}s   ", end="", flush=True)

    print()
    elapsed = time.time() - start_time
    print(f"Data sent! {elapsed:.1f}s total, {file_size/elapsed/1024:.1f} KB/s")

    # 5. Wait for DONE
    line = ser.readline()
    if b"DONE" in line:
        print("✓ Programming successful! Restart the board to play GIF.")
    else:
        print(f"WARNING: Unexpected response: {line}")

    ser.close()


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        print("Example: python send_bin.py tools/gif_data.bin COM3")
        sys.exit(1)

    port = sys.argv[2]
    baud = int(sys.argv[3]) if len(sys.argv) > 3 else 115200
    send_bin(sys.argv[1], port, baud)
