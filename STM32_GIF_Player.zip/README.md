# STM32F103C8 GIF Player — 1.54" IPS LCD 240×240

基于 STM32F103C8T6 的 GIF 动画播放器，使用 ST7789 驱动的 1.54 寸 IPS SPI 屏幕，GIF 数据存储在 W25Q64 外部 Flash 中，支持串口烧录更新。

## 硬件连接

### LCD (ST7789 1.54" IPS)
| LCD 引脚 | STM32 引脚 | 功能 |
|---------|-----------|------|
| VCC | 3.3V | 电源（**必须 3.3V！**） |
| GND | G | 地 |
| SCL | PA5 | SPI1 时钟 (18MHz) |
| SDA | PA7 | SPI1 数据 (MOSI) |
| RES | PA2 | 复位 |
| DC | PA3 | 数据/命令选择 |
| CS | PA4 | 片选 |
| BLK | PA8 | 背光 (TIM1 PWM) |

### W25Q64 SPI Flash
| Flash 引脚 | STM32 引脚 | 功能 |
|-----------|-----------|------|
| CS | PB12 | 片选 |
| SCK | PB13 | SPI2 时钟 (18MHz) |
| DO (MISO) | PB14 | 数据输出 |
| DI (MOSI) | PB15 | 数据输入 |
| VCC | 3.3V | 电源 |
| GND | G | 地 |

### USB-TTL (用于烧录 GIF 数据)
| USB-TTL | STM32 引脚 |
|---------|-----------|
| TXD | PA10 (RX) |
| RXD | PA9 (TX) |
| GND | G |

### 可选：强制进入编程模式
- 上电时 **PA15 接 GND** → 强制进入串口烧录模式
- 正常使用时 PA15 悬空即可

## 环境准备

1. 安装 VSCode + **EIDE 扩展**（Embedded IDE）
2. 安装 ARM GCC 工具链（推荐 `arm-none-eabi-gcc`）
3. 安装 STM32CubeProgrammer（ST-Link 烧录用）

## 使用方法

### 1. 编译烧录固件
用 VSCode 打开项目文件夹，EIDE 会自动下载 STM32F1 设备包。按 `Ctrl+Shift+B` → 选择 **build and flash (ST-Link)**。

### 2. 转换 GIF
```bash
pip install imageio numpy pillow
python tools/gif2bin.py your_animation.gif tools/gif_data.bin
```
生成的文件约 3.2MB（28 帧），存放在 `tools/gif_data.bin`。

### 3. 烧录 GIF 到 W25Q64
- 方法 A：上电时 PA15 接 GND → 自动进入编程模式
- 方法 B：首次上电检测不到 GIF 数据 → 自动进入编程模式

LCD 显示绿色 "READY - SEND FILE" 后，串口工具（57600 8N1）发送 `gif_data.bin`（二进制/原始模式）。约 9 分钟传完，LCD 显示绿色 "SUCCESS!"。

也可以用 `tools/send_bin.py`：
```bash
pip install pyserial
python tools/send_bin.py tools/gif_data.bin COM4
```

### 4. 播放
复位后 LCD 显示 "GIF found! Playing..."，自动循环播放。

## 性能参数

| 指标 | 数值 |
|------|------|
| CPU 频率 | 72MHz |
| LCD SPI | SPI1 @ 18MHz 硬件 |
| Flash SPI | SPI2 @ 18MHz 硬件 |
| GIF 帧率 | ~10 fps |
| W25Q64 读取 | DMA 数据阶段 |
| UART 烧录 | 57600 bps，环形缓冲 |

## 项目文件说明

| 文件 | 说明 |
|------|------|
| `main/main.c` | 主程序：GIF 播放 + UART 编程模式 |
| `main/lcd_st7789.c/h` | ST7789 LCD 驱动 |
| `main/w25q64.c/h` | W25Q64 SPI Flash 驱动 |
| `main/delay.c/h` | SysTick 毫秒延迟 |
| `main/oled.c/h` | 【可选】SSD1306 OLED 驱动 (PA6/PA7 软件 I2C) |
| `tools/gif2bin.py` | GIF → RGB565 二进制转换器 |
| `tools/send_bin.py` | PC 端串口发送工具 |

## 故障排除

- **屏幕不亮**：检查 LCD VCC 是否为 3.3V，检查 SPI 接线
- **颜色不对**：检查 GIF 转换是否使用了最新版 `gif2bin.py`
- **烧录卡在 99%**：降低波特率到 19200 重试
- **帧叠加**：确保使用 `imageio` 版 `gif2bin.py` 转换

## 许可

MIT License
